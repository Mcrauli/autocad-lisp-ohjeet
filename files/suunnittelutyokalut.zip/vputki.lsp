;;; VPUTKI.LSP - Suoran viemariputken piirtokomento (parametrinen block)
;;;
;;; Riippuvuus: rinnalla files/vputki-32.dwg, files/vputki-50.dwg ja
;;; files/vputki-75.dwg -block-kirjastot, jotka sisaltavat dynamic blockit
;;; VPUTKI-32, VPUTKI-50 ja VPUTKI-75. Blockit on parametrisoitu Linear
;;; Pituus-parametrilla (continuous, 2 grippia) -> pituutta voi venyttaa
;;; gripeilla kummasta tahansa paasta. Halkaisija on kovakoodattu
;;; blockiin (yksi DWG per koko).
;;;
;;; Erilliset DWG:t per koko valttaa AutoCAD:n self-reference-virheet
;;; samoin kuin klhylly:lla.
;;;
;;; Lataa: APPLOAD -> valitse tama tiedosto. (vputki-<size>.dwg loydetaan
;;; automaattisesti samasta kansiosta.)
;;;
;;; Komento:
;;;   VPUTKI -> 32/50/75 -> aloituspiste -> loppupiste
;;;
;;; Layerit luodaan automaattisesti: KYL-VIEMARI-32 (ACI 151, vaalea sin),
;;; KYL-VIEMARI-50 (ACI 5, sininen), KYL-VIEMARI-75 (ACI 175, tumma sin).
;;; Block-maaritysten sisalla geometria on layerilla 0 (BYBLOCK), joten
;;; instanssin layer periytyy alaspain ja IFC-vienti (dxf2ifc) tunnistaa
;;; putken koon layerin nimesta -> NominalDiameter.
;;;
;;; Editointi: native dynamic-block gripit (oikea + vasen). Koon vaihto =
;;; poista + piirra VPUTKI uudestaan. Fittings (kulmat, T-haarat) ovat
;;; erillisia staattisia WBLOCKeja V-PUTKET-kansiossa, insertoidaan
;;; plain INSERT-komennolla.

(vl-load-com)

;; ============================================================
;; LAYER-HELPER
;; ============================================================

;; Varmistaa etta layer on olemassa annetulla AutoCAD color index:lla.
;; Jos layer on jo olemassa, ei kosketa sen asetuksiin.
(defun vputki-ensure-layer ( layerName colorIndex
                              / acadObj doc layers layer )
  (if (null (tblsearch "LAYER" layerName))
    (progn
      (setq acadObj (vlax-get-acad-object))
      (setq doc (vla-get-ActiveDocument acadObj))
      (setq layers (vla-get-Layers doc))
      (setq layer (vla-Add layers layerName))
      (vla-put-Color layer colorIndex)
    )
  )
  layerName
)

;; ============================================================
;; BLOCK-DWG LOCATOR (kuvio kopioitu klhylly.lsp:sta)
;; ============================================================

(defun vputki-self-folder ( / found regbase target ver prod prof appkey val )
  (vl-load-com)
  (setq target "vputki.lsp")
  (cond
    ((setq found (findfile target))
     (vl-filename-directory found))
    (T
     (setq found nil)
     (setq regbase "HKEY_CURRENT_USER\\SOFTWARE\\Autodesk\\AutoCAD")
     (foreach ver (vl-registry-descendents regbase)
       (foreach prod (vl-registry-descendents (strcat regbase "\\" ver))
         (foreach prof (vl-registry-descendents
                         (strcat regbase "\\" ver "\\" prod "\\Profiles"))
           (setq appkey (strcat regbase "\\" ver "\\" prod
                                "\\Profiles\\" prof "\\Dialogs\\Appload"))
           (if (and (not found)
                    (setq val (vl-registry-read appkey "MainDialog"))
                    (= (type val) 'STR)
                    (findfile (strcat val "\\" target)))
             (setq found val))
         )
       )
     )
     found)
  )
)

;; Etsii block-DWG:n nimella (vputki-32.dwg, vputki-50.dwg, vputki-75.dwg).
(defun vputki-find-block-file ( dwgName / cands self prefix found p )
  (vl-load-com)
  (setq found (findfile dwgName))
  (if (and found (= (type found) 'STR))
    found
    (progn
      (setq found nil)
      (setq cands '())
      (if (setq self (vputki-self-folder))
        (if (= (type self) 'STR)
          (setq cands (list (strcat self "\\" dwgName)))))
      (setq prefix (getvar "DWGPREFIX"))
      (setq cands (append cands
        (list
          (strcat (getenv "USERPROFILE") "\\suunnittelutyokalut\\" dwgName)
          (strcat (getenv "USERPROFILE") "\\AutoCADLisp\\" dwgName)
          (strcat "C:\\AutoCADLisp\\" dwgName))))
      (if (and prefix (= (type prefix) 'STR) (> (strlen prefix) 0))
        (setq cands (append cands (list (strcat prefix dwgName)))))
      (foreach p cands
        (if (and (not found)
                 (= (type p) 'STR)
                 (vl-file-systime p))
          (setq found p)))
      found)
  )
)

;; ============================================================
;; DYNAMIC BLOCK PROPERTY -SETTERI
;; ============================================================

;; Asettaa dynamic blockin parametrin arvon nimella. Hiljaa epaonnistuu
;; jos parametria ei ole.
(defun vputki-set-dyn-prop ( ent propName value / obj props p )
  (setq obj (vlax-ename->vla-object ent))
  (setq props (vlax-invoke obj 'GetDynamicBlockProperties))
  (foreach p props
    (if (= (strcase (vla-get-PropertyName p)) (strcase propName))
      (vla-put-Value p (vlax-make-variant value vlax-vbDouble))))
  (princ))

;; ============================================================
;; BLOCK-DEFINITION LOADER
;; ============================================================

;; Varmistaa etta block-maaritys on ladattu lahde-DWG:sta. Jos on jo
;; tassa DWG:ssa, ei tee mitaan.
(defun vputki-ensure-block ( blockName dwgFileName / dwgPath )
  (if (tblsearch "BLOCK" blockName)
    T
    (progn
      (setq dwgPath (vputki-find-block-file dwgFileName))
      (if (or (null dwgPath) (not (= (type dwgPath) 'STR)))
        (progn
          (princ (strcat "\nVIRHE: " dwgFileName " ei loydy."))
          (princ "\nTarkista etta vputki-<size>.dwg on samassa kansiossa")
          (princ "\nkuin vputki.lsp tai $USERPROFILE\\suunnittelutyokalut\\.")
          nil)
        (progn
          ;; Lataa block-maaritys ilman etta luodaan instanssia.
          ;; Syntaksi: -INSERT blockname=path -> ESC peruuttaa insertin
          ;; mutta block-maaritys jaa nykyiseen DWG:hen.
          (command "_.-INSERT" (strcat blockName "=" dwgPath))
          (command)        ; peruuta INSERT, jata vain block-maaritys
          T))))
)

;; ============================================================
;; PAAKOMENTO: VPUTKI
;; ============================================================

(defun c:VPUTKI ( / *error* oldClayer oldCmdecho oldOsmode
                    size sizeNum p1 p2 dx dy len ang
                    blockName layerName aci ok blkRef )

  (defun *error* ( msg )
    (if oldOsmode  (setvar "OSMODE"  oldOsmode))
    (if oldCmdecho (setvar "CMDECHO" oldCmdecho))
    (if oldClayer  (setvar "CLAYER"  oldClayer))
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*ABORT*,*EXIT*")))
      (princ (strcat "\nVirhe: " msg)))
    (princ))

  (setq oldClayer  (getvar "CLAYER"))
  (setq oldCmdecho (getvar "CMDECHO"))
  (setq oldOsmode  (getvar "OSMODE"))

  ;; 1. Kysy koko
  (initget "32 50 75")
  (setq size (getkword "\nViemariputken koko [32/50/75] <50>: "))
  (if (null size) (setq size "50"))
  (setq sizeNum (atoi size))

  ;; 2. Block + layer nimet ja varit
  (setq blockName (strcat "VPUTKI-" size))
  (setq layerName (strcat "KYL-VIEMARI-" size))
  (cond
    ((= size "32") (setq aci 151))    ; vaalea sininen
    ((= size "50") (setq aci   5))    ; perussininen (yleisin koko)
    ((= size "75") (setq aci 175)))   ; tumma sininen (sama kuin KYL-*HYLLY)

  (vputki-ensure-layer layerName aci)

  ;; 3. Lataa block-maaritys jos puuttuu
  (setq ok (vputki-ensure-block blockName
                                (strcat "vputki-" size ".dwg")))
  (if (null ok) (exit))

  ;; 4. Pisteet
  (setq p1 (getpoint "\nAloituspiste: "))
  (if (null p1) (exit))
  (setq p2 (getpoint p1 "\nLoppupiste: "))
  (if (null p2) (exit))

  (setq dx (- (car p2) (car p1)))
  (setq dy (- (cadr p2) (cadr p1)))
  (setq len (sqrt (+ (* dx dx) (* dy dy))))
  (if (< len 1.0)
    (progn
      (princ "\nVIRHE: putki on liian lyhyt (< 1 mm). Peruutettu.")
      (exit)))
  (setq ang (* 180.0 (/ (atan dy dx) pi)))

  ;; 5. INSERT block + Pituus-parametrin asetus
  (setvar "CLAYER" layerName)
  (setvar "CMDECHO" 0)
  (command "_.-INSERT" blockName p1 1 1 ang)
  (setq blkRef (entlast))
  (vputki-set-dyn-prop blkRef "Pituus" len)

  ;; 6. Restore + raportti
  (setvar "OSMODE"  oldOsmode)
  (setvar "CMDECHO" oldCmdecho)
  (setvar "CLAYER"  oldClayer)
  (princ (strcat "\n" blockName " luotu: pituus " (rtos len 2 1) " mm."))
  (princ))

(princ "\nVPUTKI ladattu. Komento: VPUTKI")
(princ)
