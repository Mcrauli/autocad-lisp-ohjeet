;; Radika-tyokalujen autoloader (AutoCAD/BricsCAD bundle).
;; AutoCAD lataa taman LSP:n bundle-kaynnistyksen yhteydessa
;; PackageContents.xml:n LoadOnAutoCADStartup-direktiivilla.
;; Tama puolestaan lataa muut tyokalu-LSPit samasta Contents-kansiosta.

(defun radika-load-all ( / dir f )
  (setq dir (vl-filename-directory (findfile "_loader.lsp")))
  (if dir
    (foreach f '("hoyrystin.lsp" "kaato.lsp" "klhylly.lsp" "koneikko.lsp"
                 "kotelo.lsp" "lauhdutin.lsp" "positio.lsp"
                 "putkityokalu.lsp" "varusteet.lsp")
      (load (strcat dir "/" f) nil))))

(radika-load-all)
(princ "\nRadika-tyokalut ladattu (bundle).")
(princ)